package com.witnip.diagnosis.Model;

import java.io.Serializable;

public class Symptom implements Serializable {
    private String ID;
    private String Name;

    public Symptom() {
    }

    public Symptom(String ID, String name) {
        this.ID = ID;
        Name = name;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}

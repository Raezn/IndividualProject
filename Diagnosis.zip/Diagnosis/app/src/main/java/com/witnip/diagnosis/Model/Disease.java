package com.witnip.diagnosis.Model;

import java.io.Serializable;
import java.text.DecimalFormat;

public class Disease implements Serializable {
    public String ID;
    public String Name;
    private double symptomCount;
    private double totalSymptomCount;
    public double likelihood;

    public Disease() {
    }

    public Disease(String ID, String name, int symptomCount, int totalSymptomCount) {
        this.ID = ID;
        Name = name;
        this.symptomCount = symptomCount;
        this.totalSymptomCount = totalSymptomCount;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public double getSymptomCount() {
        return symptomCount;
    }

    public void setSymptomCount(double symptomCount) {
        this.symptomCount = symptomCount;
    }

    public double getTotalSymptomCount() {
        return totalSymptomCount;
    }

    public void setTotalSymptomCount(double totalSymptomCount) {
        this.totalSymptomCount = totalSymptomCount;
    }

    public double getLikelihood(){
        likelihood = (symptomCount/totalSymptomCount)*100;
        DecimalFormat df2 = new DecimalFormat("#.##");
        likelihood = Double.parseDouble(df2.format(likelihood));
        return likelihood;
    }
}

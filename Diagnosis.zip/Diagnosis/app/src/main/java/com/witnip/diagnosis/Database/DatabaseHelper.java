package com.witnip.diagnosis.Database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.witnip.diagnosis.Model.Disease;
import com.witnip.diagnosis.Model.Symptom;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {


    public DatabaseHelper(@Nullable Context context) {
        super(context, Contents.DATABASE_NAME, null, Contents.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Contents.CREATE_TABLE_DISEASE);
        db.execSQL(Contents.CREATE_TABLE_SYMPTOM);
        db.execSQL(Contents.CREATE_TABLE_DISEASE_SYMPTOM);
        db.execSQL(Contents.INSERT_INTO_DISEASE);
        db.execSQL(Contents.INSERT_INTO_SYMPTOM);
        db.execSQL(Contents.INSERT_INTO_DISEASE_SYMPTOM);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(Contents.DROP_DISEASE_TABLE);
        db.execSQL(Contents.DROP_SYMPTOM_TABLE);
        db.execSQL(Contents.DROP_DISEASE_SYMPTOM_TABLE);
        onCreate(db);
    }

    public ArrayList<Symptom> getSymptomList() {
        String query = "SELECT * FROM " + Contents.SYMPTOM_TABLE;
        ArrayList<Symptom> symptoms = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        Symptom symptom, firstElement;
        firstElement = new Symptom("0", "None");
        symptoms.add(firstElement);
        if (cursor.moveToFirst()) {
            do {
                symptom = new Symptom();

                symptom.setID(cursor.getString(0));
                symptom.setName(cursor.getString(1));
                symptoms.add(symptom);
            } while (cursor.moveToNext());
        }
        return symptoms;
    }

    public ArrayList<Disease> getDiseaseList(ArrayList<Symptom> selectedSymptoms) {
        String adQuery = null;
        ArrayList<Disease> diseases = new ArrayList<>();
        if (selectedSymptoms.size() > 0) {
            adQuery = "WHERE ";
            for (int i = 0; i < selectedSymptoms.size(); i++) {
                adQuery += Contents.FK_SYMPTOM_ID + "= '" + selectedSymptoms.get(i).getID()+"'";
                if (i != (selectedSymptoms.size() - 1)) {
                    adQuery += " OR ";
                }

            }
        }
        if (adQuery != null) {
            String query = "SELECT " +Contents.DISEASE_TABLE+"."+Contents.DISEASE_ID+","+Contents.DISEASE_TABLE+"."+Contents.DISEASE_NAME+", COUNT( "+Contents.DISEASE_SYMPTOM_TABLE + "." + Contents.FK_DISEASE_ID+") "+
                    "  FROM " + Contents.DISEASE_TABLE + " " +
                    "JOIN " + Contents.DISEASE_SYMPTOM_TABLE + " " +
                    "ON " + Contents.DISEASE_TABLE + "." + Contents.DISEASE_ID + " = " + Contents.DISEASE_SYMPTOM_TABLE + "." + Contents.FK_DISEASE_ID +" "+
                    "JOIN " + Contents.SYMPTOM_TABLE+" "+
                    "ON " + Contents.DISEASE_SYMPTOM_TABLE + "." + Contents.FK_SYMPTOM_ID + " = " + Contents.SYMPTOM_TABLE + "." + Contents.SYMPTOM_ID +" "+
                    " " + adQuery+" " +
                    "GROUP BY "+Contents.DISEASE_SYMPTOM_TABLE + "." + Contents.FK_DISEASE_ID+" " +
                    "ORDER BY "+Contents.DISEASE_SYMPTOM_TABLE+"."+Contents.ID+" ASC";
            SQLiteDatabase db = this.getWritableDatabase();
            Cursor cursor = db.rawQuery(query, null);
            Disease disease;

            if (cursor.moveToFirst()) {
                do {
                    disease = new Disease();
                    disease.setID(cursor.getString(0));
                    disease.setName(cursor.getString(1));
                    disease.setSymptomCount(cursor.getDouble(2));
                    String query2 = "SELECT COUNT("+Contents.FK_DISEASE_ID+") as totalSymptomCount FROM "+Contents.DISEASE_SYMPTOM_TABLE+" " +
                            "WHERE "+Contents.FK_DISEASE_ID+" = '"+cursor.getString(0)+"' " +
                            "GROUP BY "+Contents.FK_DISEASE_ID+" " +
                            "ORDER BY totalSymptomCount DESC";
                    Cursor cursor2 = db.rawQuery(query2, null);
                    if(cursor2.moveToFirst()){
                        do {

                            disease.setTotalSymptomCount(cursor2.getDouble(0));
                            diseases.add(disease);
                        }while (cursor2.moveToNext());
                    }
                } while (cursor.moveToNext());
            }
        }
        return diseases;
    }

}

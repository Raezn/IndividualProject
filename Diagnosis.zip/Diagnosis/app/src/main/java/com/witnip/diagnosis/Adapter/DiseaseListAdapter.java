package com.witnip.diagnosis.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.witnip.diagnosis.Model.Disease;
import com.witnip.diagnosis.R;

import java.util.ArrayList;

public class DiseaseListAdapter extends RecyclerView.Adapter<DiseaseListAdapter.DiseaseListViewHolder> {

    Context context;
    ArrayList<Disease> diseases;

    public DiseaseListAdapter(Context context, ArrayList<Disease> diseases) {
        this.context = context;
        this.diseases = diseases;
    }

    public class DiseaseListViewHolder extends RecyclerView.ViewHolder {
        TextView txtDiseaseID,txtDiseaseName;
        public DiseaseListViewHolder(@NonNull View itemView) {
            super(itemView);
            txtDiseaseID = itemView.findViewById(R.id.txtDiseaseID);
            txtDiseaseName = itemView.findViewById(R.id.txtDiseaseName);
        }
    }

    @NonNull
    @Override
    public DiseaseListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.disease_list_item,parent,false);
        DiseaseListViewHolder holder = new DiseaseListViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull DiseaseListViewHolder holder, int position) {
        Disease disease = diseases.get(position);
        holder.txtDiseaseID.setText(""+(position+1));
        holder.txtDiseaseName.setText(disease.getName());
    }

    @Override
    public int getItemCount() {
        return diseases.size();
    }


}

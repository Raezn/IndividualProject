package com.witnip.diagnosis.Model;

import java.io.Serializable;

public class DiseaseSymptom implements Serializable {
    private int ID;
    private String diseaseID;
    private String symptomID;

    public DiseaseSymptom() {
    }

    public DiseaseSymptom(String diseaseID, String symptomID) {
        this.diseaseID = diseaseID;
        this.symptomID = symptomID;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getDiseaseID() {
        return diseaseID;
    }

    public void setDiseaseID(String diseaseID) {
        this.diseaseID = diseaseID;
    }

    public String getSymptomID() {
        return symptomID;
    }

    public void setSymptomID(String symptomID) {
        this.symptomID = symptomID;
    }
}

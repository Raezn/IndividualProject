package com.witnip.diagnosis.Database;

public class Contents {
    public static final String DATABASE_NAME = "Disease_Symptom";
    public static final int DATABASE_VERSION = 1;

    //Create Disease Table
    public static final String DISEASE_TABLE = "Disease";
    public static final String DISEASE_ID = "ID";
    public static final String DISEASE_NAME = "Name";
    public static final String CREATE_TABLE_DISEASE = "CREATE TABLE "
            + DISEASE_TABLE + "("
            + DISEASE_ID + " VARCHAR(255) PRIMARY KEY ,"
            + DISEASE_NAME + " VARCHAR(255));";

    public static final String DROP_DISEASE_TABLE = "DROP TABLE IF EXISTS " + DISEASE_TABLE;

    //Create Symptom table
    public static final String SYMPTOM_TABLE = "Symptom";
    public static final String SYMPTOM_ID = "ID";
    public static final String SYMPTOM_NAME = "Name";
    public static final String CREATE_TABLE_SYMPTOM = "CREATE TABLE "
            + SYMPTOM_TABLE + "("
            + SYMPTOM_ID + " VARCHAR(255) PRIMARY KEY ,"
            + SYMPTOM_NAME + " VARCHAR(255));";

    public static final String DROP_SYMPTOM_TABLE = "DROP TABLE IF EXISTS " + SYMPTOM_TABLE;

    //Create DiseaseSymptom Table
    public static final String DISEASE_SYMPTOM_TABLE = "DiseaseSymptom";
    public static final String ID = "ID";
    public static final String FK_SYMPTOM_ID = "SymptomID";
    public static final String FK_DISEASE_ID = "DiseaseID";
    public static final String CREATE_TABLE_DISEASE_SYMPTOM = "CREATE TABLE "
            + DISEASE_SYMPTOM_TABLE + " ("
            + ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + FK_SYMPTOM_ID + " VARCHAR(255), "
            + FK_DISEASE_ID + " VARCHAR(255), " +
            "FOREIGN KEY (" + FK_SYMPTOM_ID + ") " +
            "REFERENCES " + SYMPTOM_TABLE + "(" + SYMPTOM_ID + ") " +
            "ON DELETE SET NULL, " +
            "FOREIGN KEY (" + FK_DISEASE_ID + ") " +
            "REFERENCES " + DISEASE_TABLE + "(" + DISEASE_ID + ") " +
            "ON DELETE SET NULL);";

    public static final String DROP_DISEASE_SYMPTOM_TABLE = "DROP TABLE IF EXISTS " + DISEASE_SYMPTOM_TABLE;

    //Insert Disease
    public static final String INSERT_INTO_DISEASE = "INSERT INTO " + DISEASE_TABLE + " (ID,Name) " + "VALUES " +

            "('D1','Diabetes: \n" +
            "Diabetes is a lifelong condition that causes blood sugar level to become too high.\n" +
            "There are 2 main types of diabetes:\n" +
            "•\ttype 1 diabetes – where the immune system attacks and destroys the cells that produce insulin\n" +
            "•\ttype 2 diabetes – where the body does not produce enough insulin, or cells do not react to insulin\n" +
            "For more information, visit: https://www.nhs.uk/conditions/diabetes/')," +

            "('D2','Depression: \n" +
            "Depression is more than simply feeling unhappy or fed up for a few days.\n" +
            "Most people go through periods of feeling down, but when you are depressed you feel persistently sad for weeks or months, rather than just a few days.\n" +
            "Some people think depression is trivial and not a genuine health condition. They are wrong – it is a real illness with real symptoms. Depression is not a sign of weakness or something you can \"snap out of\" by \"pulling yourself together\".\n" +
            "For more information, visit: https://www.nhs.uk/conditions/clinical-depression/')," +

            "('D3','Coronary Heart Disease: \n" +
            "CHD is a major cause of death in the UK and worldwide. It is sometimes called ischaemic heart disease or coronary artery disease.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/coronary-heart-disease/')," +

            "('D4','Pneumonia: \n" +
            "Pneumonia is swelling (inflammation) of the tissue in one or both lungs. It is usually caused by a bacterial infection.\n" +
            "At the end of the breathing tubes in your lungs are clusters of tiny air sacs.\n" +
            "If you have pneumonia, these tiny sacs become inflamed and fill up with fluid.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/pneumonia/')," +

            "('D5','Heart Failure: \n" +
            "Heart failure means that the heart is unable to pump blood around the body properly. It usually occurs because the heart has become too weak or stiff.\n" +
            "It is sometimes called congestive heart failure, although this name is not widely used nowadays.\n" +
            "Heart failure does not mean your heart has stopped working. It just needs some support to help it work better.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/heart-failure/')," +

            "('D6','Stroke: \n" +
            "A stroke is a serious life-threatening medical condition that happens when the blood supply to part of the brain is cut off.\n" +
            "Strokes are a medical emergency and urgent treatment is essential.\n" +
            "The sooner a person receives treatment for a stroke, the less damage is likely to happen.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/stroke/')," +

            "('D7','Asthma: \n" +
            "Asthma is a common lung condition that causes occasional breathing difficulties.\n" +
            "It affects people of all ages and often starts in childhood, although it can also develop for the first time in adults.\n" +
            "There is currently no cure, but there are simple treatments that can help keep the symptoms under control so it does not have a big impact on your life.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/asthma/')," +

            "('D8','Heart Attack: \n" +
            "A heart attack or myocardial infarction is a serious medical emergency in which the supply of blood to the heart is suddenly blocked, usually by a blood clot.\n" +
            "A lack of blood to the heart may seriously damage the heart muscle and can be life threatening.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/heart-attack/')," +

            "('D9','Hypercholesterolemia: \n" +
            "High cholesterol is when you have too much of a fatty substance called cholesterol in your blood.\n" +
            "It is mainly caused by eating fatty food, not exercising enough, being overweight, smoking and drinking alcohol. It can also run in families.\n" +
            "You can lower your cholesterol by eating healthily and getting more exercise. Some people also need to take medicine.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/high-cholesterol/')," +

            "('D10','Urinary Tract Infection: \n" +
            "UTIs can affect different parts of your urinary tract, including your bladder (cystitis), urethra (urethritis) or kidneys (kidney infection). Most UTIs can be easily treated with antibiotics.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/urinary-tract-infections-utis/')," +

            "('D11','Anemia: \n" +
            "Iron deficiency anaemia is caused by lack of iron, often because of blood loss or pregnancy. It is treated with iron tablets prescribed by a GP and by eating iron-rich foods.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/iron-deficiency-anaemia/')," +

            "('D12','Chronic Obstructive Pulmonary Disease: \n" +
            "Chronic obstructive pulmonary disease (COPD) is the name for a group of lung conditions that cause breathing difficulties.\n" +
            "It includes:\n" +
            "•\temphysema – damage to the air sacs in the lungs\n" +
            "•\tchronic bronchitis – long-term inflammation of the airways\n" +
            "For more information, visit: https://www.nhs.uk/conditions/chronic-obstructive-pulmonary-disease-copd/')," +

            "('D13','Dementia: \n" +
            "Dementia is a syndrome (a group of related symptoms) associated with an ongoing decline of brain functioning. This may include problems with:\n" +
            "•\tmemory loss\n" +
            "•\tthinking speed\n" +
            "•\tmental sharpness and quickness \n" +
            "•\tlanguage\n" +
            "•\tunderstanding\n" +
            "•\tjudgement\n" +
            "•\tmood \n" +
            "•\tmovement\n" +
            "•\tdifficulties carrying out daily activities\n" +
            "For more information, visit: https://www.nhs.uk/conditions/dementia/')," +

            "('D14','Chronic Kidney Disease: \n" +
            "Chronic kidney disease (CKD) is a long-term condition where the kidneys do not work as well as they should.\n" +
            "It is a common condition often associated with getting older. It can affect anyone, but it is more common in people who are black or of south Asian origin.\n" +
            "CKD can get worse over time and eventually the kidneys may stop working altogether, but this is uncommon.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/kidney-disease/')," +

            "('D15','Confusion: \n" +
            "If a person is confused, they may:\n" +
            "•\tnot be able to think or speak clearly or quickly\n" +
            "•\tnot know where they are (feel disorientated)\n" +
            "•\tstruggle to pay attention or remember things\n" +
            "•\tsee or hear things that are not there (hallucinations)\n" +
            "For more information, visit: https://www.nhs.uk/conditions/confusion/')," +

            "('D16','Arthritis: \n" +
            "Arthritis is a common condition that causes pain and inflammation in a joint.\n" +
            "In the UK, more than 10 million people have arthritis or other, similar conditions that affect the joints.\n" +
            "Arthritis affects people of all ages, including children.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/arthritis/')," +

            "('D17','Hypothyroidism: \n" +
            "An underactive thyroid gland (hypothyroidism) is where your thyroid gland does not produce enough hormones.\n" +
            "Common signs of an underactive thyroid are tiredness, weight gain and feeling depressed.\n" +
            "An underactive thyroid can often be successfully treated by taking daily hormone tablets to replace the hormones your thyroid is not making.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/underactive-thyroid-hypothyroidism/')," +

            "('D18','Anxiety: \n" +
            "Anxiety is a feeling of unease, such as worry or fear, that can be mild or severe.\n" +
            "Everyone has feelings of anxiety at some point in their life. For example, you may feel worried and anxious about sitting an exam, or having a medical test or job interview.\n" +
            "During times like these, feeling anxious can be perfectly normal.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/generalised-anxiety-disorder/')," +

            "('D19','Lung Cancer: \n" +
            "Lung cancer is one of the most common and serious types of cancer. Around 47,000 people are diagnosed with the condition every year in the UK.\n" +
            "There are usually no signs or symptoms in the early stages of lung cancer, but many people with the condition eventually develop symptoms \n" +
            "For more information, visit: https://www.nhs.uk/conditions/lung-cancer/')," +

            "('D20','HIV: \n" +
            "HIV (human immunodeficiency virus) is a virus that damages the cells in your immune system and weakens your ability to fight everyday infections and disease.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/hiv-and-aids/')," +

            "('D21','Cellulitis: /n" +
            "Cellulitis is a skin infection that is treated with antibiotics. It can be serious if it is not treated quickly. You can get cellulitis on any part of your body, but it usually affects the hands, feet and legs.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/cellulitis/')," +

            "('D22','Gastroesophageal Reflux Disease: \n" +
            "Heartburn is a burning feeling in the chest caused by stomach acid travelling up towards the throat (acid reflux). If it keeps happening, it is called gastro-oesophageal reflux disease (GORD).\n" +
            "For more information, visit: https://www.nhs.uk/conditions/heartburn-and-acid-reflux/')," +

            "('D23','Deep Vein Thrombosis: \n" +
            "DVT (deep vein thrombosis) is a blood clot in a vein, usually the leg. DVT can be dangerous. Get medical help as soon as possible if you think you have DVT.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/deep-vein-thrombosis-dvt/')," +

            "('D24','Dehydration: \n" +
            "Dehydration means your body loses more fluids than you take in. If it is not treated, it can get worse and become a serious problem.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/dehydration/')," +

            "('D25','Pulmonary Embolism: \n" +
            "A pulmonary embolism is a blocked blood vessel in your lungs. It can be life-threatening if not treated quickly.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/pulmonary-embolism/')," +

            "('D26','Epilepsy: \n" +
            "Epilepsy is a common condition that affects the brain and causes frequent seizures.\n" +
            "Seizures are bursts of electrical activity in the brain that temporarily affect how it works. They can cause a wide range of symptoms.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/epilepsy/')," +

            "('D27','Cardiomyopathy: \n" +
            "Cardiomyopathy is a general term for diseases of the heart muscle, where the walls of the heart chambers have become stretched, thickened or stiff. This affects the ability of the heart to pump blood around the body.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/cardiomyopathy/')," +

            "('D28','Hepatitis: \n" +
            "Hepatitis is the term used to describe inflammation of the liver. it is usually the result of a viral infection or liver damage caused by drinking alcohol.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/hepatitis/')," +

            "('D29','Peripheral Arterial Disease: \n" +
            "Peripheral arterial disease (PAD) is a common condition where a build-up of fatty deposits in the arteries restricts blood supply to leg muscles. it is also known as peripheral vascular disease (PVD).\n" +
            "For more information, visit: https://www.nhs.uk/conditions/peripheral-arterial-disease-pad/')," +

            "('D30','Psychosis: \n" +
            "Psychosis is when people lose some contact with reality. This might involve seeing or hearing things that other people cannot see or hear (hallucinations) and believing things that are not actually true (delusions).\n" +
            "For more information, visit: https://www.nhs.uk/conditions/psychosis/')," +

            "('D31','Bipolar Disorder: \n" +
            "Bipolar disorder is a mental health condition that affects your moods, which can swing from 1 extreme to another. It used to be known as manic depression. Unlike simple mood swings, each extreme episode of bipolar disorder can last for several weeks (or even longer).\n" +
            "For more information, visit: https://www.nhs.uk/conditions/bipolar-disorder/')," +

            "('D32','Obesity: \n" +
            "The term obese describes a person who is very overweight, with a lot of body fat. Obesity is generally caused by consuming more calories, particularly those in fatty and sugary foods, than you burn off through physical activity. The excess energy is stored by the body as fat.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/obesity/')," +

            "('D33','Cirrhosis: \n" +
            "Cirrhosis is scarring of the liver caused by long-term liver damage. The scar tissue prevents the liver working properly.\n" +
            "This can eventually lead to liver failure, where your liver stops working, which can be fatal.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/cirrhosis/')," +

            "('D34','Roseola: \n" +
            "Roseola is a very common infection that mainly affects babies and toddlers. It usually causes a high temperature and a rash. You can normally look after your child at home and they should recover within a week.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/roseola/')," +

            "('D35','Benign Prostatic Enlargement: \n" +
            "Benign prostate enlargement (BPE) is the medical term to describe an enlarged prostate, a condition that can affect how you pee (urinate).\n" +
            "BPE is common in men aged over 50. It is not a cancer and it is not usually a serious threat to health.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/prostate-enlargement/')," +

            "('D36','Acute Kidney Injury: \n" +
            "Acute kidney injury (AKI) is where your kidneys suddenly stop working properly. It can range from minor loss of kidney function to complete kidney failure.\n" +
            "AKI normally happens as a complication of another serious illness. It is not the result of a physical blow to the kidneys, as the name might suggest.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/acute-kidney-injury/')," +

            "('D37','Arthritis: \n" +
            "Arthritis is a common condition that causes pain and inflammation in a joint.\n" +
            "In the UK, more than 10 million people have arthritis or other, similar conditions that affect the joints.\n" +
            "Arthritis affects people of all ages, including children.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/arthritis/')," +

            "('D38','Bronchitis: \n" +
            "Bronchitis is an infection of the main airways of the lungs (bronchi), causing them to become irritated and inflamed. Most cases of bronchitis happen when an infection irritates and inflames the airways, causing them to produce more mucus than usual.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/bronchitis/')," +

            "('D39','Paralysis: \n" +
            "Paralysis is the loss of the ability to move some or all of the body.\n" +
            "It can have lots of different causes, some of which can be serious. Depending on the cause, it may be temporary or permanent. The main symptom of paralysis is the inability to move part of your body, or not being able to move at all.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/paralysis/')," +

            "('D40','Transient Ischemic Attack: \n" +
            "A transient ischaemic attack (TIA) or \"mini stroke\" is caused by a temporary disruption in the blood supply to part of the brain.\n" +
            "The disruption in blood supply results in a lack of oxygen to the brain.\n" +
            "This can cause sudden symptoms similar to a stroke, such as speech and visual disturbance, and numbness or weakness in the face, arms and legs.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/transient-ischaemic-attack-tia/')," +

            "('D41','Acute Pancreatitis: \n" +
            "Acute pancreatitis is a condition where the pancreas becomes inflamed (swollen) over a short period of time.\n" +
            "The pancreas is a small organ, located behind the stomach, that helps with digestion.\n" +
            "Most people with acute pancreatitis start to feel better within about a week and have no further problems. But some people with severe acute pancreatitis can go on to develop serious complications.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/acute-pancreatitis/')," +

            "('D42','Hernia: \n" +
            "A hernia occurs when an internal part of the body pushes through a weakness in the muscle or surrounding tissue wall.\n" +
            "A hernia usually develops between your chest and hips. In many cases, it causes no or very few symptoms, although you may notice a swelling or lump in your tummy (abdomen) or groin.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/hernia/')," +

            "('D43','Prostate Cancer: \n" +
            "Prostate cancer is the most common cancer in men in the UK. It usually develops slowly, so there may be no signs for many years. Symptoms of prostate cancer do not usually appear until the prostate is large enough to affect the tube that carries urine from the bladder out of the penis (urethra).\n" +
            "For more information, visit: https://www.nhs.uk/conditions/prostate-cancer/')," +

            "('D44','Breast Cancer: \n" +
            "Breast cancer is the most common type of cancer in the UK. Most women diagnosed with breast cancer are over the age of 50, but younger women can also get breast cancer.\n" +
            "About 1 in 8 women are diagnosed with breast cancer during their lifetime. There is a good chance of recovery if it is detected at an early stage.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/breast-cancer/')," +

            "('D45','Schizophrenia: \n" +
            "Schizophrenia is a severe long-term mental health condition. It causes a range of different psychological symptoms.\n" +
            "Doctors often describe schizophrenia as a type of psychosis. This means the person may not always be able to distinguish their own thoughts and ideas from reality.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/schizophrenia/')," +

            "('D46','Diverticulitis: \n" +
            "Diverticular disease and diverticulitis are related digestive conditions that affect the large intestine (bowel).\n" +
            "Diverticula are small bulges or pockets that can develop in the lining of the intestine as you get older.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/diverticular-disease-and-diverticulitis/')," +

            "('D47','Stomach Ulcer: \n" +
            "Stomach ulcers, also known as gastric ulcers, are open sores that develop on the lining of the stomach. The most common symptom of a stomach ulcer is a burning or gnawing pain in the centre of the tummy (abdomen).\n" +
            "For more information, visit: https://www.nhs.uk/conditions/stomach-ulcer/')," +

            "('D48','Osteomyelitis: \n" +
            "Osteomyelitis is an infection that most often causes pain in the long bones in the legs.\n" +
            "Other bones, such as those in the back or arms, can also be affected.\n" +
            "Anyone can develop osteomyelitis.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/osteomyelitis/')," +

            "('D49','Gastritis: \n" +
            "Gastritis occurs when the lining of the stomach becomes inflamed after it is been damaged. It is a common condition with a wide range of causes.\n" +
            "For most people, gastritis is not serious and improves quickly if treated. But if not, it can last for years.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/gastritis/')," +

            "('D50','Sickle Cell Anemia: \n" +
            "Sickle cell disease is the name for a group of inherited health conditions that affect the red blood cells. The most serious type is called sickle cell anaemia. People with sickle cell disease produce unusually shaped red blood cells that can cause problems because they do not live as long as healthy blood cells and can block blood vessels.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/sickle-cell-disease/')," +

            "('D51','Respiratory Tract Infection: \n" +
            "Respiratory tract infections (RTIs) can affect the sinuses, throat, airways or lungs. Most RTIs get better without treatment, but sometimes you may need to see your GP.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/respiratory-tract-infection/')," +

            "('D52','Hypertension Pulmonary: \n" +
            "Pulmonary hypertension is high blood pressure in the blood vessels that supply the lungs (pulmonary arteries).\n" +
            "It is a serious condition that can damage the right side of the heart.\n" +
            "The walls of the pulmonary arteries become thick and stiff and cannot expand as well to allow blood through.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/pulmonary-hypertension/')," +

            "('D53','Gout: \n" +
            "Gout causes sudden severe joint pain. See a GP for treatment to help during an attack and to stop further attacks. Gout does not cause lasting damage to joints if you get treatment straight away.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/gout/')," +

            "('D54','Hypoglycemia: \n" +
            "A low blood sugar, also called hypoglycaemia, is where the level of sugar (glucose) in your blood drops too low.\n" +
            "It mainly affects people with diabetes, especially if you take insulin.\n" +
            "A low blood sugar can be dangerous if it is not treated promptly, but you can usually treat it easily yourself.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/low-blood-sugar-hypoglycaemia/')," +

            "('D55','Ulcerative Colitis: \n" +
            "Ulcerative colitis is a long-term condition where the colon and rectum become inflamed.\n" +
            "The colon is the large intestine (bowel) and the rectum is the end of the bowel where stools are stored.\n" +
            "Small ulcers can develop on the lining of the colon, and can bleed and produce pus.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/ulcerative-colitis/')," +

            "('D56','Parkinsons Disease: \n" +
            "Parkinsons disease is a condition in which parts of the brain become progressively damaged over many years. A person with Parkinsons disease can also experience a wide range of physical and psychological symptoms.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/parkinsons-disease/')," +

            "('D57','Hyperglycemia: \n" +
            "Hyperglycaemia is the medical term for a high blood sugar (glucose) level. it is a common problem for people with diabetes.\n" +
            "It can affect people with type 1 diabetes and type 2 diabetes, as well as pregnant women with gestational diabetes.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/high-blood-sugar-hyperglycaemia/')," +

            "('D58','Encephalitis: \n" +
            "Encephalitis is an uncommon but serious condition in which the brain becomes inflamed (swollen).\n" +
            "It can be life threatening and requires urgent treatment in hospital.\n" +
            "Anyone can be affected, but the very young and very old are most at risk.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/encephalitis/')," +

            "('D59','Alzheimers Disease: \n" +
            "Alzheimers disease is the most common type of dementia in the UK.\n" +
            "Dementia is a syndrome (a group of related symptoms) associated with an ongoing decline of brain functioning. It can affect memory, thinking skills and other mental abilities.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/alzheimers-disease/')," +

            "('D60','Neuropathy: \n" +
            "Peripheral neuropathy develops when nerves in the extremities of the body, such as the hands, feet and arms, are damaged. The symptoms depend on which nerves are affected.\n" +
            "In the UK it is estimated almost 1 in 10 people aged 55 or over are affected by peripheral neuropathy.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/peripheral-neuropathy/')," +

            "('D61','Glaucoma: \n" +
            "Glaucoma is a common eye condition where the optic nerve, which connects the eye to the brain, becomes damaged.\n" +
            "It is usually caused by fluid building up in the front part of the eye, which increases pressure inside the eye.\n" +
            "Glaucoma can lead to loss of vision if it is not diagnosed and treated early.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/glaucoma/')," +

            "('D62','Diabetic Ketoacidosis: \n" +
            "Diabetic ketoacidosis (DKA) is a serious problem that can occur in people with diabetes if their body starts to run out of insulin.\n" +
            "This causes harmful substances called ketones to build up in the body, which can be life-threatening if not spotted and treated quickly.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/diabetic-ketoacidosis/')," +

            "('D63','Epilepsy: \n" +
            "Epilepsy is a common condition that affects the brain and causes frequent seizures.\n" +
            "Seizures are bursts of electrical activity in the brain that temporarily affect how it works. They can cause a wide range of symptoms.\n" +
            "Epilepsy can start at any age, but usually starts either in childhood or in people over 60.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/epilepsy/')," +

            "('D64','Personality Disorder: \n" +
            "A person with a personality disorder thinks, feels, behaves or relates to others very differently from the average person. A person with borderline personality disorder (one of the most common types) tends to have disturbed ways of thinking, impulsive behaviour and problems controlling their emotions.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/personality-disorder/')," +

            "('D65','Liver Cancer: \n" +
            "Primary liver cancer is an uncommon but serious type of cancer that begins in the liver.\n" +
            "This is a separate condition from secondary liver cancer, where the cancer developed in another part of the body and spread to the liver.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/liver-cancer/')," +

            "('D66','Hemorrhoids: \n" +
            "Piles (haemorrhoids) are lumps inside and around your bottom (anus). They often get better on their own after a few days.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/piles-haemorrhoids/')," +

            "('D67','Aphasia: \n" +
            "Aphasia is when a person has difficulty with their language or speech. It is usually caused by damage to the left side of the brain (for example, after a stroke).\n" +
            "For more information, visit: https://www.nhs.uk/conditions/aphasia/')," +

            "('D68','Kidney Infection: \n" +
            "A kidney infection is a painful and unpleasant illness usually caused by cystitis, a common infection of the bladder.\n" +
            "Most people with cystitis will not get a kidney infection, but occasionally the bacteria can travel up from the bladder into 1 or both kidneys.\n" +
            "If treated with antibiotics straight away, a kidney infection does not cause serious harm, although you will feel very unwell.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/kidney-infection/')," +

            "('D69','Endocarditis: \n" +
            "Endocarditis is a rare and potentially fatal infection of the inner lining of the heart (the endocardium). It is most commonly caused by bacteria entering the blood and travelling to the heart.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/endocarditis/')," +

            "('D70','Pericarditis: \n" +
            "Pericarditis causes chest pain and a high temperature (fever). It is not usually serious, but it can cause complications. Get medical advice if you have chest pain.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/pericarditis/')," +

            "('D71','Acute Cholecystitis: \n" +
            "Acute cholecystitis is inflammation of the gallbladder. It usually happens when a gallstone blocks the cystic duct.\n" +
            "Gallstones are small stones, usually made of cholesterol, that form in the gallbladder. The cystic duct is the main opening of the gallbladder.\n" +
            "Gallstones are very common, affecting about 1 in 10 adults in the UK.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/acute-cholecystitis/')," +

            "('D72','Migraine Disorder: \n" +
            "A migraine is usually a moderate or severe headache felt as a throbbing pain on 1 side of the head.\n" +
            "Many people also have symptoms such as feeling sick, being sick and increased sensitivity to light or sound.\n" +
            "Migraine is a common health condition, affecting around 1 in every 5 women and around 1 in every 15 men. They usually begin in early adulthood.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/migraine/')," +

            "('D73','Common Cold: \n" +
            "You can often treat a cold without seeing a GP. You should begin to feel better in about a week or 2. Colds are caused by viruses and easily spread to other people. You are infectious until all your symptoms have gone.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/common-cold/')," +

            "('D74','Acute Lymphoblastic Leukaemia: \n" +
            "Acute lymphoblastic leukaemia is a type of cancer that affects white blood cells. It progresses quickly and aggressively and requires immediate treatment. Both adults and children can be affected.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/acute-lymphoblastic-leukaemia/')," +

            "('D75','Acute Pancreatitis: \n" +
            "Acute pancreatitis is a condition where the pancreas becomes inflamed (swollen) over a short period of time.\n" +
            "The pancreas is a small organ, located behind the stomach, that helps with digestion.\n" +
            "Most people with acute pancreatitis start to feel better within about a week and have no further problems. But some people with severe acute pancreatitis can go on to develop serious complications.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/acute-pancreatitis/')," +

            "('D76','Addisons Disease: \n" +
            "Addisons disease, also known as primary adrenal insufficiency or hypoadrenalism, is a rare disorder of the adrenal glands.\n" +
            "The adrenal glands are 2 small glands that sit on top of the kidneys. They produce 2 essential hormones: cortisol and aldosterone.\n" +
            "The adrenal gland is damaged in Addisons disease, so it does not produce enough cortisol or aldosterone.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/addisons-disease/')," +

            "('D77','Anal Cancer: \n" +
            "Anal cancer is a rare type of cancer that affects the anus (the end of the bowel). The symptoms of anal cancer are often similar to more common and less serious conditions affecting the anus, such as piles (haemorrhoids) and small tears or sores called anal fissures.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/anal-cancer/')," +

            "('D78','Anaphylaxis: \n" +
            "Anaphylaxis is a severe and potentially life-threatening reaction to a trigger such as an allergy. Anaphylaxis usually develops suddenly and gets worse very quickly.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/anaphylaxis/')," +

            "('D79','Anorexia Nervosa: \n" +
            "Anorexia is an eating disorder and serious mental health condition.\n" +
            "People who have anorexia try to keep their weight as low as possible by not eating enough food or exercising too much, or both. This can make them very ill because they start to starve.\n" +
            "They often have a distorted image of their bodies, thinking they are fat even when they are underweight.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/anorexia/')," +

            "('D80','Appendicitis: \n" +
            "Appendicitis is a painful swelling of the appendix. The appendix is a small, thin pouch about 5 to 10cm (2 to 4 inches) long. It is connected to the large intestine, where fecal matter forms.\n" +
            "Nobody knows exactly what the appendix does, but removing it is not harmful.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/appendicitis/')," +

            "('D81','Atopic Eczema: \n" +
            "Atopic eczema (atopic dermatitis) is the most common form of eczema, a condition that causes the skin to become itchy, dry and cracked.\n" +
            "It is more common in children, often developing before their first birthday. However, it can also develop for the first time in adults.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/atopic-eczema/')," +

            "('D82','Attention Defecit Hyperactivity Disorder: \n" +
            "Attention deficit hyperactivity disorder (ADHD) is a behavioural disorder that includes symptoms such as inattentiveness, hyperactivity and impulsiveness.\n" +
            "Symptoms of ADHD tend to be noticed at an early age and may become more noticeable when circumstances change, such as when a child starts school.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/attention-deficit-hyperactivity-disorder-adhd/')," +

            "('D83','Bile Duct Cancer: \n" +
            "Cancer of the bile duct (cholangiocarcinoma) is a rare type of cancer that mainly affects adults aged over 65.\n" +
            "Bile ducts are small tubes that connect the liver and small intestine. They allow fluid called bile to flow from the liver, through the pancreas, to the gut, where it helps with digestion. Cancer can affect any part of these ducts.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/bile-duct-cancer/')," +

            "('D84','Sepsis: \n" +
            "Sepsis is a life-threatening reaction to an infection.\n" +
            "It happens when your immune system overreacts to an infection and starts to damage tissues and organs.\n" +
            "You cannot catch sepsis from another person.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/sepsis/')," +

            "('D85','Bladder Cancer: \n" +
            "Bladder cancer is where a growth of abnormal tissue, known as a tumour, develops in the bladder lining. In some cases, the tumour spreads into the bladder muscle.\n" +
            "The most common symptom of bladder cancer is blood in your urine, which is usually painless.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/bladder-cancer/')," +

            "('D86','Brain Tumour: \n" +
            "A brain tumour is a growth of cells in the brain that multiplies in an abnormal, uncontrollable way. The symptoms of a brain tumour vary depending on the exact part of the brain affected.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/brain-tumours/')," +

            "('D87','Catarrh: \n" +
            "Catarrh is a build-up of mucus in an airway or cavity of the body.\n" +
            "It usually affects the back of the nose, the throat or the sinuses (air-filled cavities in the bones of the face).\n" +
            "It is often temporary, but some people experience it for months or years. This is known as chronic catarrh.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/catarrh/')," +

            "('D88','Chest Infection: \n" +
            "A chest infection is an infection of the lungs or large airways. Some chest infections are mild and clear up on their own, but others can be severe and life threatening. Chest infections often follow colds or flu.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/chest-infection/')," +

            "('D89','Clostridium Difficile: \n" +
            "Clostridium difficile, also known as C. difficile or C. diff, is bacteria that can infect the bowel and cause diarrhoea.\n" +
            "The infection most commonly affects people who have recently been treated with antibiotics. It can spread easily to others.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/c-difficile/')," +

            "('D90','Cold Sore: \n" +
            "Cold sores are caused by a virus called herpes simplex.\n" +
            "Once you have the virus, it stays in your skin for the rest of your life. Sometimes it causes a cold sore.\n" +
            "Most people are exposed to the virus when they are young after close contact with someone who has a cold sore.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/cold-sores/')," +

            "('D91','Conjunctivitis: \n" +
            "Conjunctivitis is an eye condition caused by infection or allergies. It usually gets better in a couple of weeks without treatment. It is also known as red or pink eye.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/conjunctivitis/')," +

            "('D92','Coronavirus: \n" +
            "Do not leave your home if you have coronavirus symptoms\n" +
            "Do not leave your home if you have either:\n" +
            "•\ta high temperature – this means you feel hot to touch on your chest or back (you do not need to measure your temperature)\n" +
            "•\ta new, continuous cough – this means coughing a lot for more than an hour, or 3 or more coughing episodes in 24 hours (if you usually have a cough, it may be worse than usual)\n" +
            "For more information, visit: https://www.nhs.uk/conditions/coronavirus-covid-19/')," +

            "('D93','Flu: \n" +
            "You can often treat the flu without seeing a GP and should begin to feel better in about a week. Flu is very infectious and easily spread to other people. You are more likely to give it to others in the first 5 days.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/flu/')," +

            "('D94','Food Poisoning: \n" +
            "Food poisoning is rarely serious and usually gets better within a week. You can normally treat yourself or your child at home. The symptoms usually start within a few days of eating the food that caused the infection. The symptoms usually pass within a week.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/food-poisoning/')," +

            "('D95','Hayfever: \n" +
            "Hay fever is usually worse between late March and September, especially when it is warm, humid and windy. This is when the pollen count is at its highest. Hay fever will last for weeks or months, unlike a cold, which usually goes away after 1 to 2 weeks.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/hay-fever/')," +

            "('D96','Irritable Bowel Syndrome: \n" +
            "Irritable bowel syndrome (IBS) is a common condition that affects the digestive system. It causes symptoms like stomach cramps, bloating, diarrhoea and constipation. These tend to come and go over time, and can last for days, weeks or months at a time.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/irritable-bowel-syndrome-ibs/')," +

            "('D97','Lactose Intolerance: \n" +
            "Lactose intolerance is a common digestive problem where the body is unable to digest lactose, a type of sugar mainly found in milk and dairy products. Symptoms of lactose intolerance usually develop within a few hours of consuming food or drink that contains lactose.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/lactose-intolerance/')," +

            "('D98','Laryngitis: \n" +
            "Laryngitis is when your voice box or vocal cords in the throat become irritated or swollen. It usually goes away by itself within 1 to 2 weeks. Laryngitis usually comes on suddenly and gets worse during the first 3 days.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/laryngitis/')," +

            "('D99','Lyme Disease: \n" +
            "Lyme disease is a bacterial infection that can be spread to humans by infected ticks. It is usually easier to treat if it is diagnosed early. Many people with early symptoms of Lyme disease develop a circular red skin rash around a tick bite.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/lyme-disease/')," +

            "('D100','Malaria: \n" +
            "Malaria is a serious tropical disease spread by mosquitoes. If it is not diagnosed and treated promptly, it can be fatal.\n" +
            "A single mosquito bite is all it takes for someone to become infected.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/malaria/')," +

            "('D101','Measles: \n" +
            "Measles is a highly infectious viral illness that can be very unpleasant and sometimes lead to serious complications. It is now uncommon in the UK because of the effectiveness of vaccination.\n" +
            "Anyone can get measles if they have not been vaccinated or have not had it before, although it is most common in young children.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/measles/')," +

            "('D102','Middle Ear Infection: \n" +
            "Ear infections are very common, particularly in children. You do not always need to see a GP for an ear infection as they often get better on their own within 3 days.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/ear-infections/')," +

            "('D103','Mumps: \n" +
            "Mumps is a contagious viral infection that used to be common in children before the introduction of the MMR vaccine. Mumps is most recognisable by the painful swellings in the side of the face under the ears (the parotid glands), giving a person with mumps a distinctive \"hamster face\" appearance.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/mumps/')," +

            "('D104','Norovirus: \n" +
            "Norovirus, also called the \"winter vomiting bug\", is a stomach bug that causes vomiting and diarrhoea. It can be very unpleasant, but usually goes away in about 2 days.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/norovirus/')," +

            "('D105','Panic Disorder: \n" +
            "Panic disorder is an anxiety disorder where you regularly have sudden attacks of panic or fear.\n" +
            "Everyone experiences feelings of anxiety and panic at certain times. It is a natural response to stressful or dangerous situations.\n" +
            "But for someone with panic disorder, feelings of anxiety, stress and panic occur regularly and at any time, often for no apparent reason.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/panic-disorder/')," +

            "('D106','Scarlet Fever: \n" +
            "Scarlet fever is a contagious infection that mostly affects young children. It is easily treated with antibiotics. The first signs of scarlet fever can be flu-like symptoms, including a high temperature of 38C or above, a sore throat and swollen neck glands (a large lump on the side of your neck).\n" +
            "For more information, visit: https://www.nhs.uk/conditions/scarlet-fever/')," +

            "('D107','Stomach Cancer: \n" +
            "Stomach cancer is a cancer that is found anywhere in the stomach. It is not very common in the UK. These symptoms are very common and can be caused by many different conditions. Having them does not definitely mean you have stomach cancer. But it is important to get them checked by a GP.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/stomach-cancer/')," +

            "('D108','Yellow Fever: \n" +
            "Yellow fever is a serious infection spread by mosquitoes. It is found in parts of Africa, South America, Central America and the Caribbean.\n" +
            "There is no cure for yellow fever, but the symptoms can be treated while your body fights off the infection.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/yellow-fever/')," +

            "('D109','Bowel Cancer: \n" +
            "Bowel cancer is a general term for cancer that begins in the large bowel. Depending on where the cancer starts, bowel cancer is sometimes called colon or rectal cancer.\n" +
            "Bowel cancer is one of the most common types of cancer diagnosed in the UK. Most people diagnosed with it are over the age of 60.\n" +
            "For more information, visit: https://www.nhs.uk/conditions/bowel-cancer/');";

    //Insert Symptoms
    public static final String INSERT_INTO_SYMPTOM = "INSERT INTO " + SYMPTOM_TABLE + " (ID,Name) " + "VALUES " +
            "('S1','Abdominal Pain')," +
            "('S2','Abscess')," +
            "('S3','Absent Pulse')," +
            "('S4','Ache')," +
            "('S5','Agitation')," +
            "('S6','Altered Mental Status')," +
            "('S7','Anorexia')," +
            "('S8','Auditory Hallucinations')," +
            "('S9','Back Pain')," +
            "('S10','Barking Cough')," +
            "('S11','Bedridden')," +
            "('S12','Blackout')," +
            "('S13','Bloating')," +
            "('S14','Blocked Nose')," +
            "('S15','Blocked Throat')," +
            "('S16','Bloody Stool')," +
            "('S17','Bloody Urination')," +
            "('S18','Blue Skin')," +
            "('S19','Blurred Vision')," +
            "('S20','Bone Pain')," +
            "('S21','Breakthrough Pain')," +
            "('S22','Breast Lump')," +
            "('S23','Breathlessness')," +
            "('S24','Bruised Skin')," +
            "('S25','Bulging Neck Vein')," +
            "('S26','Burning Eyes')," +
            "('S27','Burning Sensation')," +
            "('S28','Catatonia')," +
            "('S29','Chest Discomfort')," +
            "('S30','Chest Pain')," +
            "('S31','Chills')," +
            "('S32','Choking')," +
            "('S33','Clammy Skin')," +
            "('S34','Clumsiness')," +
            "('S35','Confusion')," +
            "('S36','Constipation')," +
            "('S37','Cough')," +
            "('S38','Coughing Blood')," +
            "('S39','Craving for Salty Foods')," +
            "('S40','Cyst')," +
            "('S41','Dark Urine')," +
            "('S42','Decreased Blood Pressure After Standing')," +
            "('S43','Decreased Bowel Sounds')," +
            "('S44','Decreased Breathing Sounds')," +
            "('S45','Decreased Movement')," +
            "('S46','Decreased Muscle Tone')," +
            "('S47','Dehydration')," +
            "('S48','Depressed Mood')," +
            "('S49','Diarrhoea')," +
            "('S50','Difficult Urination')," +
            "('S51','Difficulty Breathing')," +
            "('S52','Difficulty Breathing While Lying')," +
            "('S53','Difficulty Speaking')," +
            "('S54','Discharge from Anus')," +
            "('S55','Discoloured Skin')," +
            "('S56','Disorientation')," +
            "('S57','Dizziness')," +
            "('S58','Drool')," +
            "('S59','Drowsiness')," +
            "('S60','Dry Cough')," +
            "('S61','Dry Mouth')," +
            "('S62','Dry Skin')," +
            "('S63','Dullness')," +
            "('S64','Ear Discharge')," +
            "('S65','Earache')," +
            "('S66','Early Satiety')," +
            "('S67','Excessive Body Hair')," +
            "('S68','Excessive Salivation')," +
            "('S69','Excessive Urination')," +
            "('S70','Excruciating Pain')," +
            "('S71','Exhaustion')," +
            "('S72','Eye Discharge')," +
            "('S73','Eye Rolling')," +
            "('S74','Facial Paralysis')," +
            "('S75','Fainting')," +
            "('S76','Falling')," +
            "('S77','Fatigue')," +
            "('S78','Fear of Sound')," +
            "('S79','Feces in Rectum')," +
            "('S80','Feeling Strange')," +
            "('S81','Feeling Suicidal')," +
            "('S82','Flare')," +
            "('S83','Flatulence')," +
            "('S84','Food Intolerance')," +
            "('S85','Foot Pain')," +
            "('S86','Formication')," +
            "('S87','Frequent Bleeding')," +
            "('S88','Frequent Urination')," +
            "('S89','Gagging')," +
            "('S90','General Difficulty')," +
            "('S91','General Discomfort')," +
            "('S92','Green Sputum')," +
            "('S93','Grogginess')," +
            "('S94','Hacking Cough')," +
            "('S95','Haemorrhage')," +
            "('S96','Hair Loss')," +
            "('S97','Hand Numbness')," +
            "('S98','Hand Tremors')," +
            "('S99','Hard Feces Consistency')," +
            "('S100','Headache')," +
            "('S101','Heartburn')," +
            "('S102','Heavy Legs')," +
            "('S103','High Heart Rate')," +
            "('S104','High Temperature')," +
            "('S105','Hoarseness')," +
            "('S106','Hopelessness')," +
            "('S107','Hot Flush')," +
            "('S108','Hunger')," +
            "('S109','Hyperactivity')," +
            "('S110','Hypersomnia')," +
            "('S111','Hyperventilation')," +
            "('S112','Hypothermia')," +
            "('S113','Hypoxemia')," +
            "('S114','Impulsiveness')," +
            "('S115','Inability to Concentrate')," +
            "('S116','Inability to Swallow')," +
            "('S117','Inattentiveness')," +
            "('S118','Incoherent Speech')," +
            "('S119','Increased Auditory Sensitivity')," +
            "('S120','Increased Energy')," +
            "('S121','Indifferent Mood')," +
            "('S122','Indigestion')," +
            "('S123','Inflammation')," +
            "('S124','Intoxication')," +
            "('S125','Involuntary Muscle Contractions')," +
            "('S126','Involuntary Urination')," +
            "('S127','Irregular Heartbeat')," +
            "('S128','Irritable Mood')," +
            "('S129','Itchiness')," +
            "('S130','Joint Pain')," +
            "('S131','Laboured Breathing')," +
            "('S132','Leg Cramp')," +
            "('S133','Lethargy')," +
            "('S134','Lightheadedness')," +
            "('S135','Limb Pain')," +
            "('S136','Lip Smacking')," +
            "('S137','Loose Associations')," +
            "('S138','Loose Stool')," +
            "('S139','Loss of Appetite')," +
            "('S140','Loss of Bowel Control')," +
            "('S141','Loss of Hearing')," +
            "('S142','Loss of Sensitivity')," +
            "('S143','Loss of Smell')," +
            "('S144','Low Blood Pressure')," +
            "('S145','Low Urination')," +
            "('S146','Lower Back Pain')," +
            "('S147','Lower Limb Pain')," +
            "('S148','Lumps Around Anus')," +
            "('S149','Memory Absence')," +
            "('S150','Migraine')," +
            "('S151','Moodiness')," +
            "('S152','Motor Retardation')," +
            "('S153','Muscle Pain')," +
            "('S154','Muscle Spasm')," +
            "('S155','Muscle Twitch')," +
            "('S156','Muscle Weakness')," +
            "('S157','Nausea')," +
            "('S158','Neck Stiffness')," +
            "('S159','Nervousness')," +
            "('S160','Night Sweats')," +
            "('S161','Nightmares')," +
            "('S162','Noisy Breathing')," +
            "('S163','Numbness')," +
            "('S164','Overweight')," +
            "('S165','Pain')," +
            "('S166','Painful Swallowing')," +
            "('S167','Painful Urination')," +
            "('S168','Pale Skin')," +
            "('S169','Palpitation')," +
            "('S170','Paralysis')," +
            "('S171','Partial Body Paralysis')," +
            "('S172','Pelvic Pain')," +
            "('S173','Pinpoint Pupils')," +
            "('S174','Pins and Needles')," +
            "('S175','Projectile Vomiting')," +
            "('S176','Prostate Pain')," +
            "('S177','Pupil Dilation')," +
            "('S178','Purple Skin')," +
            "('S179','Pus Sputum')," +
            "('S180','Pustule')," +
            "('S181','Rale')," +
            "('S182','Rambling Speech')," +
            "('S183','Rapid Breathing')," +
            "('S184','Rapid Shallow Breathing')," +
            "('S185','Rash')," +
            "('S186','Rectal Bleeding')," +
            "('S187','Rectal Pain')," +
            "('S188','Red Blotches')," +
            "('S189','Red Eyes')," +
            "('S190','Red Skin')," +
            "('S191','Redness')," +
            "('S192','Regurgitation')," +
            "('S193','Respiratory Distress')," +
            "('S194','Rest Pain')," +
            "('S195','Resting Tremor')," +
            "('S196','Rhonchus')," +
            "('S197','Rigor')," +
            "('S198','Ringing in Ears')," +
            "('S199','Room Spinning')," +
            "('S200','Rounded Face')," +
            "('S201','Runny Nose')," +
            "('S202','Scaredness')," +
            "('S203','Scratch Marks')," +
            "('S204','Seizure')," +
            "('S205','Sensitivity to Light')," +
            "('S206','Sensory Discomfort')," +
            "('S207','Shaking')," +
            "('S208','Sharp Chest Pain')," +
            "('S209','Shooting Pain')," +
            "('S210','Side Pain')," +
            "('S211','Skin Bleeding')," +
            "('S212','Sleepiness')," +
            "('S213','Sleeplessness')," +
            "('S214','Slow Heart Rate')," +
            "('S215','Slow Speech')," +
            "('S216','Slurred Speech')," +
            "('S217','Sneezing')," +
            "('S218','Sniffle')," +
            "('S219','Snoring')," +
            "('S220','Sore Throat')," +
            "('S221','Soreness')," +
            "('S222','Spasm')," +
            "('S223','Stiffness')," +
            "('S224','Stinging')," +
            "('S225','Stomach Cramps')," +
            "('S226','Stones Passed')," +
            "('S227','Stuffy Nose')," +
            "('S228','Sweating')," +
            "('S229','Swelling')," +
            "('S230','Swollen Abdomen')," +
            "('S231','Swollen Glands')," +
            "('S232','Swollen Tongue')," +
            "('S233','Thirst')," +
            "('S234','Throbbing')," +
            "('S235','Tight Chest')," +
            "('S236','Tiredness')," +
            "('S237','Tissue Injury')," +
            "('S238','Tremor')," +
            "('S239','Ulcers')," +
            "('S240','Unconsciousness')," +
            "('S241','Uncoordination')," +
            "('S242','Unresponsiveness')," +
            "('S243','Urgency of Urination')," +
            "('S244','Urinary Hesitation')," +
            "('S245','Vaginal Bleeding')," +
            "('S246','Verbal and Auditory Hallucinations')," +
            "('S247','Vertigo')," +
            "('S248','Vision Field Loss')," +
            "('S249','Visual Hallucinations')," +
            "('S250','Visual Impairment')," +
            "('S251','Vomiting')," +
            "('S252','Waking Up Early')," +
            "('S253','Weakness')," +
            "('S254','Weepiness')," +
            "('S255','Weight Gain')," +
            "('S256','Weight Loss')," +
            "('S257','Wet Cough')," +
            "('S258','Wheezing')," +
            "('S259','White Spots in Mouth')," +
            "('S260','Worriedness')," +
            "('S261','Yellow Eyes')," +
            "('S262','Yellow Skin')," +
            "('S263','Yellow Sputum')," +
            "('S264','Yellow Stool');";

    //Insert into disease symptom
    public static final String INSERT_INTO_DISEASE_SYMPTOM = "INSERT INTO " + DISEASE_SYMPTOM_TABLE + " (SymptomID,DiseaseID) " + "VALUES " +
            "('S69','D1')," +
            "('S233','D1')," +
            "('S23','D1')," +
            "('S30','D1')," +
            "('S77','D1')," +
            "('S157','D1')," +
            "('S52','D1')," +
            "('S181','D1')," +
            "('S228','D1')," +
            "('S242','D1')," +
            "('S6','D1')," +
            "('S247','D1')," +
            "('S251','D1')," +
            "('S131','D1')," +

            "('S81','D2')," +
            "('S8','D2')," +
            "('S106','D2')," +
            "('S254','D2')," +
            "('S213','D2')," +
            "('S152','D2')," +
            "('S128','D2')," +
            "('S12','D2')," +
            "('S48','D2')," +
            "('S249','D2')," +
            "('S260','D2')," +
            "('S5','D2')," +
            "('S238','D2')," +
            "('S124','D2')," +
            "('S246','D2')," +
            "('S120','D2')," +
            "('S90','D2')," +
            "('S161','D2')," +
            "('S115','D2')," +

            "('S30','D3')," +
            "('S23','D3')," +
            "('S45','D3')," +
            "('S228','D3')," +
            "('S235','D3')," +
            "('S52','D3')," +

            "('S37','D4')," +
            "('S104','D4')," +
            "('S23','D4')," +
            "('S181','D4')," +
            "('S257','D4')," +
            "('S208','D4')," +
            "('S263','D4')," +
            "('S44','D4')," +
            "('S31','D4')," +
            "('S196','D4')," +
            "('S92','D4')," +
            "('S60','D4')," +
            "('S258','D4')," +
            "('S38','D4')," +
            "('S193','D4')," +
            "('S183','D4')," +
            "('S253','D4')," +
            "('S160','D4')," +

            "('S23','D5')," +
            "('S52','D5')," +
            "('S25','D5')," +
            "('S181','D5')," +
            "('S37','D5')," +
            "('S258','D5')," +

            "('S215','D6')," +
            "('S77','D6')," +
            "('S216','D6')," +
            "('S74','D6')," +
            "('S171','D6')," +
            "('S242','D6')," +
            "('S204','D6')," +
            "('S163','D6')," +

            "('S258','D7')," +
            "('S37','D7')," +
            "('S23','D7')," +
            "('S235','D7')," +
            "('S60','D7')," +
            "('S208','D7')," +
            "('S257','D7')," +
            "('S193','D7')," +

            "('S30','D8')," +
            "('S228','D8')," +
            "('S23','D8')," +
            "('S45','D8')," +
            "('S30','D8')," +
            "('S235','D8')," +
            "('S52','D8')," +
            "('S181','D8')," +
            "('S235','D8')," +
            "('S169','D8')," +
            "('S29','D8')," +
            "('S214','D8')," +
            "('S75','D8')," +

            "('S165','D9')," +
            "('S30','D9')," +
            "('S228','D9')," +
            "('S235','D9')," +
            "('S75','D9')," +
            "('S163','D9')," +
            "('S29','D9')," +
            "('S23','D9')," +
            "('S260','D9')," +
            "('S214','D9')," +

            "('S104','D10')," +
            "('S167','D10')," +
            "('S17','D10')," +
            "('S133','D10')," +
            "('S77','D10')," +
            "('S193','D10')," +
            "('S50','D10')," +
            "('S6','D10')," +

            "('S236','D11')," +
            "('S133','D11')," +
            "('S169','D11')," +
            "('S168','D11')," +
            "('S100','D11')," +
            "('S198','D11')," +
            "('S129','D11')," +
            "('S96','D11')," +
            "('S166','D11')," +
            "('S239','D11')," +

            "('S23','D12')," +
            "('S258','D12')," +
            "('S37','D12')," +
            "('S193','D12')," +
            "('S179','D12')," +
            "('S113','D12')," +
            "('S235','D12')," +

            "('S104','D13')," +
            "('S76','D13')," +
            "('S242','D13')," +
            "('S133','D13')," +
            "('S5','D13')," +
            "('S55','D13')," +
            "('S75','D13')," +
            "('S181','D13')," +
            "('S240','D13')," +
            "('S37','D13')," +
            "('S11','D13')," +
            "('S165','D13')," +
            "('S74','D13')," +
            "('S1','D13')," +
            "('S196','D13')," +
            "('S56','D13')," +
            "('S8','D13')," +

            "('S23','D14')," +
            "('S52','D14')," +
            "('S181','D14')," +
            "('S16','D14')," +
            "('S77','D14')," +
            "('S6','D14')," +
            "('S90','D14')," +
            "('S49','D14')," +
            "('S144','D14')," +
            "('S44','D14')," +
            "('S229','D14')," +
            "('S45','D14')," +

            "('S204','D15')," +
            "('S126','D15')," +
            "('S133','D15')," +
            "('S216','D15')," +
            "('S76','D15')," +
            "('S6','D15')," +
            "('S98','D15')," +
            "('S240','D15')," +
            "('S5','D15')," +
            "('S155','D15')," +
            "('S77','D15')," +
            "('S211','D15')," +
            "('S57','D15')," +
            "('S100','D15')," +
            "('S215','D15')," +
            "('S134','D15')," +
            "('S238','D15')," +
            "('S242','D15')," +

            "('S165','D16')," +
            "('S123','D16')," +
            "('S97','D16')," +
            "('S91','D16')," +
            "('S190','D16')," +
            "('S156','D16')," +
            "('S130','D16')," +
            "('S223','D16')," +

            "('S23','D17')," +
            "('S59','D17')," +
            "('S211','D17')," +
            "('S76','D17')," +
            "('S56','D17')," +
            "('S69','D17')," +
            "('S144','D17')," +
            "('S90','D17')," +
            "('S75','D17')," +
            "('S161','D17')," +
            "('S216','D17')," +
            "('S255','D17')," +
            "('S77','D17')," +
            "('S5','D17')," +
            "('S6','D17')," +
            "('S152','D17')," +
            "('S251','D17')," +
            "('S163','D17')," +

            "('S260','D18')," +
            "('S81','D18')," +
            "('S213','D18')," +
            "('S106','D18')," +
            "('S128','D18')," +
            "('S238','D18')," +
            "('S12','D18')," +
            "('S254','D18')," +
            "('S159','D18')," +
            "('S249','D18')," +
            "('S86','D18')," +
            "('S90','D18')," +
            "('S30','D18')," +
            "('S5','D18')," +
            "('S169','D18')," +
            "('S8','D18')," +
            "('S48','D18')," +
            "('S107','D18')," +
            "('S165','D18')," +
            "('S161','D18')," +

            "('S37','D19')," +
            "('S38','D19')," +
            "('S23','D19')," +
            "('S236','D19')," +
            "('S256','D19')," +
            "('S165','D19')," +
            "('S51','D19')," +

            "('S104','D20')," +
            "('S160','D20')," +
            "('S37','D20')," +
            "('S256','D20')," +
            "('S31','D20')," +
            "('S49','D20')," +
            "('S208','D20')," +
            "('S183','D20')," +
            "('S257','D20')," +
            "('S46','D20')," +
            "('S81','D20')," +

            "('S190','D21')," +
            "('S165','D21')," +
            "('S229','D21')," +
            "('S191','D21')," +
            "('S104','D21')," +
            "('S2','D21')," +
            "('S142','D21')," +
            "('S119','D21')," +
            "('S129','D21')," +
            "('S30','D21')," +
            "('S203','D21')," +
            "('S31','D21')," +
            "('S221','D21')," +

            "('S165','D22')," +
            "('S30','D22')," +
            "('S27','D22')," +
            "('S66','D22')," +
            "('S234','D22')," +
            "('S235','D22')," +
            "('S206','D22')," +
            "('S157','D22')," +
            "('S91','D22')," +
            "('S36','D22')," +
            "('S169','D22')," +
            "('S1','D22')," +
            "('S101','D22')," +
            "('S228','D22')," +
            "('S77','D22')," +

            "('S229','D23')," +
            "('S165','D23')," +
            "('S55','D23')," +
            "('S23','D23')," +
            "('S147','D23')," +
            "('S181','D23')," +
            "('S190','D23')," +
            "('S144','D23')," +
            "('S125','D23')," +
            "('S60','D23')," +
            "('S191','D23')," +

            "('S104','D24')," +
            "('S49','D24')," +
            "('S251','D24')," +
            "('S144','D24')," +
            "('S157','D24')," +
            "('S134','D24')," +
            "('S6','D24')," +
            "('S7','D24')," +
            "('S77','D24')," +
            "('S206','D24')," +
            "('S75','D24')," +
            "('S133','D24')," +
            "('S57','D24')," +
            "('S75','D24')," +

            "('S23','D25')," +
            "('S113','D25')," +
            "('S183','D25')," +
            "('S30','D25')," +
            "('S208','D25')," +
            "('S158','D25')," +
            "('S263','D25')," +
            "('S257','D25')," +
            "('S242','D25')," +
            "('S193','D25')," +
            "('S258','D25')," +
            "('S60','D25')," +

            "('S204','D26')," +
            "('S256','D26')," +
            "('S150','D26')," +
            "('S155','D26')," +
            "('S59','D26')," +
            "('S238','D26')," +
            "('S242','D26')," +
            "('S171','D26')," +
            "('S154','D26')," +
            "('S212','D26')," +
            "('S133','D26')," +

            "('S23','D27')," +
            "('S52','D27')," +
            "('S45','D27')," +
            "('S25','D27')," +
            "('S169','D27')," +
            "('S30','D27')," +
            "('S75','D27')," +
            "('S263','D27')," +
            "('S181','D27')," +
            "('S255','D27')," +

            "('S153','D28')," +
            "('S104','D28')," +
            "('S157','D28')," +
            "('S236','D28')," +
            "('S139','D28')," +
            "('S1','D28')," +
            "('S41','D28')," +
            "('S129','D28')," +
            "('S262','D28')," +
            "('S261','D28')," +

            "('S23','D29')," +
            "('S194','D29')," +
            "('S30','D29')," +
            "('S242','D29')," +
            "('S131','D29')," +
            "('S221','D29')," +
            "('S7','D29')," +
            "('S212','D29')," +

            "('S8','D30')," +
            "('S81','D30')," +
            "('S249','D30')," +
            "('S152','D30')," +
            "('S12','D30')," +
            "('S246','D30')," +
            "('S106','D30')," +
            "('S128','D30')," +
            "('S5','D30')," +
            "('S238','D30')," +
            "('S28','D30')," +
            "('S254','D30')," +
            "('S213','D30')," +
            "('S120','D30')," +
            "('S124','D30')," +
            "('S260','D30')," +
            "('S109','D30')," +
            "('S48','D30')," +
            "('S202','D30')," +
            "('S161','D30')," +

            "('S81','D31')," +
            "('S120','D31')," +
            "('S128','D31')," +
            "('S5','D31')," +
            "('S8','D31')," +
            "('S246','D31')," +
            "('S254','D31')," +
            "('S109','D31')," +
            "('S28','D31')," +
            "('S106','D31')," +
            "('S260','D31')," +
            "('S213','D31')," +
            "('S110','D31')," +
            "('S90','D31')," +
            "('S249','D31')," +
            "('S228','D31')," +
            "('S177','D31')," +
            "('S137','D31')," +
            "('S124','D31')," +
            "('S152','D31')," +
            "('S12','D31')," +
            "('S238','D31')," +
            "('S71','D31')," +

            "('S165','D32')," +
            "('S228','D32')," +
            "('S219','D32')," +
            "('S30','D32')," +
            "('S23','D32')," +
            "('S164','D32')," +
            "('S48','D32')," +
            "('S55','D32')," +

            "('S76','D33')," +
            "('S129','D33')," +
            "('S1','D33')," +
            "('S230','D33')," +
            "('S237','D33')," +
            "('S16','D33')," +
            "('S221','D33')," +
            "('S245','D33')," +

            "('S104','D34')," +
            "('S129','D34')," +
            "('S55','D34')," +
            "('S237','D34')," +
            "('S191','D34')," +
            "('S100','D34')," +
            "('S130','D34')," +
            "('S229','D34')," +
            "('S190','D34')," +
            "('S205','D34')," +
            "('S31','D34')," +
            "('S203','D34')," +
            "('S165','D34')," +
            "('S166','D34')," +

            "('S6','D35')," +
            "('S253','D35')," +
            "('S12','D35')," +
            "('S42','D35')," +
            "('S52','D35')," +
            "('S160','D35')," +
            "('S193','D35')," +
            "('S7','D35')," +
            "('S215','D35')," +

            "('S144','D36')," +
            "('S145','D36')," +
            "('S77','D36')," +
            "('S112','D36')," +
            "('S49','D36')," +
            "('S95','D36')," +
            "('S242','D36')," +

            "('S165','D37')," +
            "('S213','D37')," +
            "('S77','D37')," +
            "('S75','D37')," +
            "('S229','D37')," +
            "('S56','D37')," +
            "('S23','D37')," +
            "('S230','D37')," +

            "('S37','D38')," +
            "('S258','D38')," +
            "('S23','D38')," +
            "('S235','D38')," +
            "('S104','D38')," +
            "('S220','D38')," +
            "('S257','D38')," +
            "('S160','D38')," +
            "('S38','D38')," +
            "('S131','D38')," +
            "('S218','D38')," +
            "('S94','D38')," +
            "('S31','D38')," +
            "('S258','D38')," +
            "('S256','D38')," +

            "('S215','D39')," +
            "('S253','D39')," +
            "('S77','D39')," +
            "('S116','D39')," +
            "('S204','D39')," +
            "('S217','D39')," +
            "('S204','D39')," +
            "('S171','D39')," +
            "('S242','D39')," +
            "('S212','D39')," +
            "('S59','D39')," +
            "('S224','D39')," +
            "('S170','D39')," +
            "('S125','D39')," +
            "('S74','D39')," +

            "('S216','D40')," +
            "('S215','D40')," +
            "('S74','D40')," +
            "('S77','D40')," +
            "('S158','D40')," +
            "('S247','D40')," +
            "('S163','D40')," +
            "('S134','D40')," +
            "('S19','D40')," +
            "('S100','D40')," +
            "('S199','D40')," +
            "('S75','D40')," +
            "('S90','D40')," +
            "('S182','D40')," +
            "('S34','D40')," +

            "('S251','D41')," +
            "('S1','D41')," +
            "('S157','D41')," +
            "('S165','D41')," +
            "('S49','D41')," +
            "('S264','D41')," +
            "('S197','D41')," +
            "('S221','D41')," +

            "('S1','D42')," +
            "('S165','D42')," +
            "('S111','D42')," +
            "('S70','D42')," +
            "('S89','D42')," +
            "('S157','D42')," +
            "('S171','D42')," +
            "('S221','D42')," +
            "('S95','D42')," +
            "('S84','D42')," +
            "('S3','D42')," +
            "('S77','D42')," +

            "('S17','D43')," +
            "('S77','D43')," +
            "('S223','D43')," +
            "('S226','D43')," +
            "('S208','D43')," +
            "('S16','D43')," +
            "('S181','D43')," +
            "('S44','D43')," +
            "('S243','D43')," +
            "('S167','D43')," +
            "('S49','D43')," +
            "('S247','D43')," +
            "('S253','D43')," +
            "('S248','D43')," +
            "('S196','D43')," +
            "('S42','D43')," +
            "('S256','D43')," +

            "('S22','D44')," +
            "('S174','D44')," +
            "('S56','D44')," +
            "('S190','D44')," +
            "('S90','D44')," +
            "('S237','D44')," +
            "('S27','D44')," +
            "('S229','D44')," +
            "('S86','D44')," +

            "('S8','D45')," +
            "('S212','D45')," +
            "('S128','D45')," +
            "('S246','D45')," +
            "('S5','D45')," +
            "('S260','D45')," +
            "('S249','D45')," +
            "('S256','D45')," +

            "('S1','D46')," +
            "('S2','D46')," +
            "('S63','D46')," +
            "('S188','D46')," +
            "('S49','D46')," +
            "('S221','D46')," +
            "('S167','D46')," +
            "('S165','D46')," +
            "('S251','D46')," +
            "('S1','D46')," +
            "('S104','D46')," +
            "('S56','D46')," +
            "('S243','D46')," +
            "('S7','D46')," +
            "('S36','D46')," +

            "('S1','D47')," +
            "('S171','D47')," +
            "('S157','D47')," +
            "('S251','D47')," +
            "('S223','D47')," +
            "('S23','D47')," +
            "('S30','D47')," +
            "('S171','D47')," +
            "('S108','D47')," +
            "('S159','D47')," +

            "('S165','D48')," +
            "('S191','D48')," +
            "('S176','D48')," +
            "('S104','D48')," +
            "('S50','D48')," +
            "('S221','D48')," +
            "('S229','D48')," +
            "('S190','D48')," +
            "('S2','D48')," +
            "('S85','D48')," +
            "('S244','D48')," +

            "('S1','D49')," +
            "('S251','D49')," +
            "('S157','D49')," +
            "('S124','D49')," +
            "('S95','D49')," +
            "('S16','D49')," +
            "('S165','D49')," +
            "('S256','D49')," +
            "('S221','D49')," +
            "('S57','D49')," +

            "('S21','D50')," +
            "('S9','D50')," +
            "('S165','D50')," +
            "('S23','D50')," +
            "('S218','D50')," +
            "('S30','D50')," +
            "('S1','D50')," +
            "('S92','D50')," +
            "('S100','D50')," +

            "('S37','D51')," +
            "('S220','D51')," +
            "('S258','D51')," +
            "('S23','D51')," +
            "('S131','D51')," +
            "('S104','D51')," +
            "('S227','D51')," +
            "('S60','D51')," +
            "('S218','D51')," +
            "('S121','D51')," +
            "('S10','D51')," +
            "('S223','D51')," +
            "('S208','D51')," +
            "('S160','D51')," +
            "('S257','D51')," +
            "('S196','D51')," +
            "('S184','D51')," +
            "('S162','D51')," +
            "('S201','D51')," +
            "('S23','D51')," +
            "('S253','D51')," +
            "('S40','D51')," +

            "('S23','D52')," +
            "('S102','D52')," +
            "('S44','D52')," +
            "('S158','D52')," +
            "('S18','D52')," +
            "('S144','D52')," +

            "('S107','D53')," +
            "('S165','D53')," +
            "('S191','D53')," +
            "('S229','D53')," +
            "('S190','D53')," +
            "('S23','D53')," +
            "('S221','D53')," +
            "('S45','D53')," +

            "('S242','D54')," +
            "('S112','D54')," +
            "('S118','D54')," +
            "('S132','D54')," +
            "('S240','D54')," +
            "('S33','D54')," +
            "('S69','D54')," +
            "('S193','D54')," +
            "('S144','D54')," +

            "('S104','D55')," +
            "('S92','D55')," +
            "('S251','D55')," +
            "('S157','D55')," +
            "('S252','D55')," +
            "('S165','D55')," +
            "('S157','D55')," +
            "('S31','D55')," +
            "('S187','D55')," +
            "('S243','D55')," +
            "('S1','D55')," +

            "('S76','D56')," +
            "('S223','D56')," +
            "('S5','D56')," +
            "('S171','D56')," +
            "('S90','D56')," +
            "('S242','D56')," +
            "('S75','D56')," +
            "('S74','D56')," +
            "('S42','D56')," +
            "('S260','D56')," +
            "('S59','D56')," +
            "('S17','D56')," +
            "('S238','D56')," +
            "('S160','D56')," +
            "('S212','D56')," +

            "('S221','D57')," +
            "('S129','D57')," +
            "('S80','D57')," +
            "('S180','D57')," +
            "('S200','D57')," +
            "('S256','D57')," +
            "('S48','D57')," +
            "('S258','D57')," +
            "('S204','D57')," +

            "('S241','D58')," +
            "('S98','D58')," +
            "('S95','D58')," +
            "('S59','D58')," +
            "('S212','D58')," +
            "('S149','D58')," +
            "('S150','D58')," +
            "('S204','D58')," +
            "('S253','D58')," +
            "('S242','D58')," +
            "('S45','D58')," +

            "('S58','D59')," +
            "('S5','D59')," +
            "('S161','D59')," +
            "('S196','D59')," +
            "('S173','D59')," +
            "('S11','D59')," +
            "('S253','D59')," +
            "('S195','D59')," +
            "('S74','D59')," +
            "('S93','D59')," +
            "('S155','D59')," +
            "('S238','D59')," +
            "('S37','D59')," +
            "('S104','D59')," +

            "('S77','D60')," +
            "('S163','D60')," +
            "('S157','D60')," +
            "('S56','D60')," +
            "('S209','D60')," +
            "('S165','D60')," +
            "('S156','D60')," +

            "('S76','D61')," +
            "('S230','D61')," +
            "('S56','D61')," +
            "('S174','D61')," +
            "('S5','D61')," +
            "('S240','D61')," +
            "('S27','D61')," +
            "('S237','D61')," +

            "('S69','D62')," +
            "('S251','D62')," +
            "('S157','D62')," +
            "('S1','D62')," +
            "('S80','D62')," +
            "('S159','D62')," +
            "('S1','D62')," +
            "('S192','D62')," +
            "('S19','D62')," +
            "('S244','D62')," +
            "('S49','D62')," +
            "('S204','D62')," +
            "('S150','D62')," +
            "('S59','D62')," +

            "('S136','D63')," +
            "('S154','D63')," +
            "('S238','D63')," +
            "('S78','D63')," +
            "('S73','D63')," +
            "('S212','D63')," +
            "('S67','D63')," +
            "('S151','D63')," +
            "('S155','D63')," +
            "('S242','D63')," +
            "('S100','D63')," +
            "('S149','D63')," +
            "('S222','D63')," +
            "('S256','D63')," +

            "('S106','D64')," +
            "('S8','D64')," +
            "('S128','D64')," +
            "('S213','D64')," +
            "('S5','D64')," +
            "('S254','D64')," +
            "('S48','D64')," +
            "('S203','D64')," +
            "('S157','D64')," +
            "('S71','D64')," +
            "('S210','D64')," +
            "('S260','D64')," +
            "('S126','D64')," +
            "('S159','D64')," +
            "('S129','D64')," +

            "('S253','D65')," +
            "('S230','D65')," +
            "('S95','D65')," +
            "('S261','D65')," +
            "('S112','D65')," +
            "('S1','D65')," +
            "('S256','D65')," +
            "('S23','D65')," +
            "('S262','D65')," +
            "('S129','D65')," +

            "('S43','D66')," +
            "('S138','D66')," +
            "('S157','D66')," +
            "('S108','D66')," +
            "('S49','D66')," +
            "('S57','D66')," +
            "('S125','D66')," +
            "('S165','D66')," +
            "('S27','D66')," +
            "('S16','D66')," +
            "('S97','D66')," +
            "('S258','D66')," +
            "('S37','D66')," +
            "('S23','D66')," +

            "('S74','D67')," +
            "('S116','D67')," +
            "('S155','D67')," +
            "('S170','D67')," +
            "('S146','D67')," +
            "('S154','D67')," +
            "('S23','D67')," +

            "('S165','D68')," +
            "('S243','D68')," +
            "('S17','D68')," +
            "('S251','D68')," +
            "('S31','D68')," +
            "('S49','D68')," +
            "('S157','D68')," +
            "('S1','D68')," +
            "('S153','D68')," +
            "('S104','D68')," +
            "('S31','D68')," +
            "('S208','D68')," +

            "('S153','D69')," +
            "('S160','D69')," +
            "('S82','D69')," +
            "('S23','D69')," +
            "('S52','D69')," +
            "('S2','D69')," +
            "('S144','D69')," +
            "('S37','D69')," +
            "('S44','D69')," +
            "('S256','D69')," +
            "('S45','D69')," +

            "('S23','D70')," +
            "('S134','D70')," +
            "('S4','D70')," +
            "('S209','D70')," +
            "('S165','D70')," +
            "('S104','D70')," +
            "('S52','D70')," +
            "('S220','D70')," +

            "('S157','D71')," +
            "('S1','D71')," +
            "('S228','D71')," +
            "('S165','D71')," +
            "('S49','D71')," +
            "('S261','D71')," +
            "('S262','D71')," +
            "('S36','D71')," +
            "('S79','D71')," +
            "('S99','D71')," +
            "('S230','D71')," +

            "('S251','D72')," +
            "('S57','D72')," +
            "('S163','D72')," +
            "('S157','D72')," +
            "('S100','D72')," +
            "('S205','D72')," +
            "('S104','D72')," +

            "('S220','D73')," +
            "('S201','D73')," +
            "('S217','D73')," +
            "('S37','D73')," +

            "('S168','D74')," +
            "('S236','D74')," +
            "('S87','D74')," +
            "('S104','D74')," +
            "('S160','D74')," +
            "('S130','D74')," +
            "('S24','D74')," +
            "('S231','D74')," +
            "('S1','D74')," +
            "('S256','D74')," +
            "('S178','D74')," +

            "('S1','D75')," +
            "('S157','D75')," +
            "('S49','D75')," +
            "('S122','D75')," +
            "('S104','D75')," +
            "('S262','D75')," +
            "('S230','D75')," +

            "('S77','D76')," +
            "('S133','D76')," +
            "('S156','D76')," +
            "('S128','D76')," +
            "('S256','D76')," +
            "('S243','D76')," +
            "('S233','D76')," +
            "('S39','D76')," +

            "('S186','D77')," +
            "('S187','D77')," +
            "('S148','D77')," +
            "('S54','D77')," +
            "('S140','D77')," +

            "('S129','D78')," +
            "('S229','D78')," +
            "('S75','D78')," +
            "('S258','D78')," +
            "('S1','D78')," +
            "('S240','D78')," +
            "('S157','D78')," +
            "('S251','D78')," +

            "('S139','D79')," +
            "('S256','D79')," +
            "('S1','D79')," +
            "('S36','D79')," +
            "('S77','D79')," +
            "('S229','D79')," +
            "('S57','D79')," +
            "('S112','D79')," +

            "('S1','D80')," +
            "('S157','D80')," +
            "('S139','D80')," +
            "('S49','D80')," +
            "('S104','D80')," +

            "('S62','D81')," +
            "('S123','D81')," +
            "('S211','D81')," +
            "('S129','D81')," +

            "('S117','D82')," +
            "('S109','D82')," +
            "('S114','D82')," +
            "('S149','D82')," +

            "('S262','D83')," +
            "('S129','D83')," +
            "('S261','D83')," +
            "('S41','D83')," +
            "('S256','D83')," +
            "('S1','D83')," +
            "('S104','D83')," +
            "('S139','D83')," +

            "('S57','D84')," +
            "('S49','D84')," +
            "('S157','D84')," +
            "('S251','D84')," +
            "('S216','D84')," +
            "('S153','D84')," +
            "('S23','D84')," +
            "('S145','D84')," +
            "('S168','D84')," +
            "('S240','D84')," +

            "('S88','D85')," +
            "('S243','D85')," +
            "('S167','D85')," +
            "('S172','D85')," +
            "('S20','D85')," +
            "('S256','D85')," +
            "('S229','D85')," +

            "('S100','D86')," +
            "('S204','D86')," +
            "('S157','D86')," +
            "('S251','D86')," +
            "('S59','D86')," +
            "('S149','D86')," +
            "('S171','D86')," +
            "('S250','D86')," +
            "('S216','D86')," +

            "('S201','D87')," +
            "('S37','D87')," +
            "('S227','D87')," +
            "('S15','D87')," +
            "('S100','D87')," +
            "('S143','D87')," +
            "('S141','D87')," +

            "('S37','D88')," +
            "('S263','D88')," +
            "('S92','D88')," +
            "('S23','D88')," +
            "('S258','D88')," +
            "('S104','D88')," +
            "('S103','D88')," +
            "('S30','D88')," +
            "('S56','D88')," +
            "('S35','D88')," +

            "('S49','D89')," +
            "('S1','D89')," +
            "('S47','D89')," +
            "('S100','D89')," +
            "('S145','D89')," +
            "('S104','D89')," +
            "('S139','D89')," +
            "('S256','D89')," +

            "('S229','D90')," +
            "('S220','D90')," +
            "('S68','D90')," +
            "('S104','D90')," +
            "('S47','D90')," +
            "('S157','D90')," +
            "('S100','D90')," +
            "('S239','D90')," +

            "('S189','D91')," +
            "('S72','D91')," +
            "('S26','D91')," +
            "('S231','D91')," +
            "('S205','D91')," +

            "('S104','D92')," +
            "('S60','D92')," +
            "('S104','D92')," +
            "('S236','D92')," +
            "('S23','D92')," +
            "('S77','D92')," +
            "('S100','D92')," +

            "('S104','D93')," +
            "('S236','D93')," +
            "('S253','D93')," +
            "('S100','D93')," +
            "('S165','D93')," +
            "('S60','D93')," +
            "('S49','D93')," +
            "('S157','D93')," +
            "('S251','D93')," +
            "('S220','D93')," +
            "('S201','D93')," +
            "('S14','D93')," +
            "('S217','D93')," +
            "('S139','D93')," +

            "('S157','D94')," +
            "('S251','D94')," +
            "('S49','D94')," +
            "('S1','D94')," +
            "('S253','D94')," +
            "('S139','D94')," +
            "('S104','D94')," +
            "('S153','D94')," +
            "('S31','D94')," +

            "('S217','D95')," +
            "('S201','D95')," +
            "('S14','D95')," +
            "('S129','D95')," +
            "('S72','D95')," +
            "('S37','D95')," +
            "('S100','D95')," +
            "('S143','D95')," +
            "('S77','D95')," +
            "('S236','D95')," +
            "('S65','D95')," +

            "('S1','D96')," +
            "('S49','D96')," +
            "('S36','D96')," +
            "('S230','D96')," +
            "('S83','D96')," +
            "('S133','D96')," +
            "('S9','D96')," +

            "('S83','D97')," +
            "('S49','D97')," +
            "('S13','D97')," +
            "('S1','D97')," +
            "('S157','D97')," +

            "('S105','D98')," +
            "('S220','D98')," +
            "('S104','D98')," +
            "('S37','D98')," +
            "('S15','D98')," +
            "('S53','D98')," +

            "('S185','D99')," +
            "('S229','D99')," +
            "('S77','D99')," +
            "('S153','D99')," +
            "('S130','D99')," +
            "('S100','D99')," +
            "('S104','D99')," +
            "('S31','D99')," +
            "('S223','D99')," +

            "('S104','D100')," +
            "('S100','D100')," +
            "('S228','D100')," +
            "('S31','D100')," +
            "('S251','D100')," +
            "('S153','D100')," +
            "('S49','D100')," +
            "('S77','D100')," +

            "('S201','D101')," +
            "('S14','D101')," +
            "('S72','D101')," +
            "('S229','D101')," +
            "('S205','D101')," +
            "('S104','D101')," +
            "('S259','D101')," +
            "('S165','D101')," +
            "('S37','D101')," +
            "('S139','D101')," +
            "('S236','D101')," +
            "('S128','D101')," +
            "('S133','D101')," +

            "('S65','D102')," +
            "('S104','D102')," +
            "('S157','D102')," +
            "('S133','D102')," +
            "('S141','D102')," +
            "('S64','D102')," +

            "('S100','D103')," +
            "('S130','D103')," +
            "('S157','D103')," +
            "('S61','D103')," +
            "('S1','D103')," +
            "('S236','D103')," +
            "('S139','D103')," +
            "('S104','D103')," +
            "('S229','D103')," +
            "('S231','D103')," +

            "('S157','D104')," +
            "('S175','D104')," +
            "('S49','D104')," +
            "('S104','D104')," +
            "('S100','D104')," +
            "('S225','D104')," +
            "('S135','D104')," +

            "('S127','D105')," +
            "('S228','D105')," +
            "('S107','D105')," +
            "('S31','D105')," +
            "('S23','D105')," +
            "('S32','D105')," +
            "('S30','D105')," +
            "('S157','D105')," +
            "('S57','D105')," +
            "('S75','D105')," +
            "('S174','D105')," +
            "('S61','D105')," +
            "('S243','D105')," +
            "('S198','D105')," +
            "('S207','D105')," +

            "('S185','D106')," +
            "('S231','D106')," +
            "('S139','D106')," +
            "('S157','D106')," +
            "('S251','D106')," +
            "('S190','D106')," +
            "('S232','D106')," +

            "('S122','D107')," +
            "('S83','D107')," +
            "('S101','D107')," +
            "('S13','D107')," +
            "('S157','D107')," +
            "('S1','D107')," +
            "('S166','D107')," +
            "('S251','D107')," +
            "('S16','D107')," +
            "('S139','D107')," +
            "('S256','D107')," +
            "('S236','D107')," +
            "('S230','D107')," +
            "('S262','D107')," +
            "('S261','D107')," +

            "('S104','D108')," +
            "('S100','D108')," +
            "('S157','D108')," +
            "('S251','D108')," +
            "('S153','D108')," +
            "('S9','D108')," +
            "('S139','D108')," +
            "('S262','D108')," +
            "('S261','D108')," +
            "('S87','D108')," +

            "('S16','D109')," +
            "('S1','D109')," +
            "('S49','D109')," +
            "('S13','D109')," +
            "('S91','D109')," +
            "('S36','D109')," +
            "('S256','D109')," +
            "('S230','D109');";

}

package com.witnip.diagnosis;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.witnip.diagnosis.Adapter.SelectedSymptomAdapter;
import com.witnip.diagnosis.Adapter.SymptomAdapter;
import com.witnip.diagnosis.Database.DatabaseHelper;
import com.witnip.diagnosis.Model.Symptom;

import java.util.ArrayList;

public class SymptomChecker extends AppCompatActivity {

    Button btnHelp;
    ImageButton btnGoToHome;
    FloatingActionButton btnOK;
    Spinner spSymptom;
    RecyclerView rvSelectedSymptoms;
    RecyclerView.LayoutManager layoutManager;

    DatabaseHelper helper;
    SymptomAdapter symptomAdapter;
    SelectedSymptomAdapter selectedSymptomAdapter;
    ArrayList<Symptom> symptoms = new ArrayList<>();
    ArrayList<Symptom> selectedSymptoms = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptom_checker);

        btnGoToHome = findViewById(R.id.btnGoToHome);
        btnHelp = findViewById(R.id.btnHelp);
        spSymptom = findViewById(R.id.spSymptom);
        rvSelectedSymptoms = findViewById(R.id.rvSelectedSymptoms);
        btnOK = findViewById(R.id.btnOK);

        helper = new DatabaseHelper(this);
        if(helper.getSymptomList() == null){
            Symptom firstElement = new Symptom("0","None");
            symptoms.add(firstElement);
        }
        symptoms = helper.getSymptomList();

        symptomAdapter = new SymptomAdapter(this,symptoms);
        spSymptom.setAdapter(symptomAdapter);

        spSymptom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Symptom symptom = (Symptom) parent.getItemAtPosition(position);
                if(!symptom.getID().equals("0") && !symptom.getName().equals("None")){
                    if(!selectedSymptoms.contains(symptom)){
                        selectedSymptoms.add(symptom);
                    }
                    rvSelectedSymptoms.setHasFixedSize(true);
                    layoutManager = new LinearLayoutManager(SymptomChecker.this);
                    rvSelectedSymptoms.setLayoutManager(layoutManager);
                    selectedSymptomAdapter = new SelectedSymptomAdapter(SymptomChecker.this,selectedSymptoms);
                    rvSelectedSymptoms.setAdapter(selectedSymptomAdapter);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        btnGoToHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SymptomChecker.this,Home.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SymptomChecker.this,Help.class);
                startActivity(intent);
            }
        });

        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SymptomChecker.this,DiseaseList.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("selectedSymptoms",selectedSymptoms);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}

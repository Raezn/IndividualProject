package com.witnip.diagnosis;

import androidx.annotation.LongDef;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.witnip.diagnosis.Adapter.DiseaseListAdapter;
import com.witnip.diagnosis.Database.DatabaseHelper;
import com.witnip.diagnosis.Model.Disease;
import com.witnip.diagnosis.Model.Symptom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DiseaseList extends AppCompatActivity {

    Button btnHelp;
    ImageButton btnGoToHome;
    RecyclerView rvDiseaseList;
    RecyclerView.LayoutManager layoutManager;
    DiseaseListAdapter diseaseListAdapter;

    DatabaseHelper helper;
    ArrayList<Symptom> selectedSymptoms = new ArrayList<>();
    ArrayList<Disease> diseases = new ArrayList<>();
    ArrayList<Disease> newDiseases = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disease_list);

        btnGoToHome = findViewById(R.id.btnGoToHome);
        btnHelp = findViewById(R.id.btnHelp);
        rvDiseaseList = findViewById(R.id.rvDiseaseList);

        Bundle bundle = getIntent().getExtras();
        selectedSymptoms = (ArrayList<Symptom>) bundle.getSerializable("selectedSymptoms");

        helper = new DatabaseHelper(this);
        diseases = helper.getDiseaseList(selectedSymptoms);

        //Showing only top three disease
        Collections.sort(diseases, new Comparator<Disease>() {
            @Override
            public int compare(Disease d1, Disease d2) {
                return Double.valueOf(d2.getLikelihood()).compareTo(d1.getLikelihood());
            }
        });
        int count = 0;
        for(Disease disease : diseases){
            Log.d("Disease", "Name : "+disease.getName()+" Likelihood : "+disease.getLikelihood());
            if(count < 3){
                newDiseases.add(disease);
            }
            count++;
        }

        if(selectedSymptoms.size() > 0){
            diseases = helper.getDiseaseList(selectedSymptoms);
            rvDiseaseList.setHasFixedSize(true);
            layoutManager = new LinearLayoutManager(this);
            rvDiseaseList.setLayoutManager(layoutManager);
            diseaseListAdapter = new DiseaseListAdapter(this,newDiseases);
            rvDiseaseList.setAdapter(diseaseListAdapter);
        } else{
            Disease disease = new Disease("0","NO MATCHING DATA FOUND",0,0);
            diseases.add(disease);
            rvDiseaseList.setHasFixedSize(true);
            layoutManager = new LinearLayoutManager(this);
            rvDiseaseList.setLayoutManager(layoutManager);
            diseaseListAdapter = new DiseaseListAdapter(this,diseases);
            rvDiseaseList.setAdapter(diseaseListAdapter);
        }


        btnGoToHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DiseaseList.this,Home.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DiseaseList.this,Help.class);
                startActivity(intent);
            }
        });
    }
}

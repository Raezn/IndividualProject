package com.witnip.diagnosis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Home extends AppCompatActivity {

    Button btnHelp,btnSymptomChecker,btnAssistant;
    ImageButton btnGoToHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnGoToHome = findViewById(R.id.btnGoToHome);
        btnHelp = findViewById(R.id.btnHelp);
        btnSymptomChecker= findViewById(R.id.btnSymptomChecker);
        btnAssistant= findViewById(R.id.btnAssistant);

        btnGoToHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,Home.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,Help.class);
                startActivity(intent);
            }
        });

        btnSymptomChecker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,SymptomChecker.class);
                startActivity(intent);
            }
        });

        btnAssistant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,Assistant.class);
                startActivity(intent);
            }
        });
    }
}

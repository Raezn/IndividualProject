package com.witnip.diagnosis.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.witnip.diagnosis.Model.Symptom;
import com.witnip.diagnosis.R;

import java.util.ArrayList;

public class SymptomAdapter extends ArrayAdapter<Symptom> {

    public SymptomAdapter(@NonNull Context context, ArrayList<Symptom> symptoms) {
        super(context,0, symptoms);
    }

    public class SymptomViewHolder{
        TextView txtSymptom;

        SymptomViewHolder(View view){
            txtSymptom = view.findViewById(R.id.txtSymptom);
        }
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return listItem(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return listItem(position, convertView, parent);
    }

    public View listItem(int position, View convertView, ViewGroup parent){
        SymptomViewHolder holder;
        // Get the data item for this position

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.symptom_spinner, parent, false);
            holder = new SymptomViewHolder(convertView);
            convertView.setTag(holder);
        }else{
            holder = (SymptomViewHolder) convertView.getTag();
        }
        Symptom symptom = getItem(position);
        holder.txtSymptom.setText(symptom.getName());
        // Return the completed view to render on screen
        return convertView;
    }
}

package com.witnip.diagnosis.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.witnip.diagnosis.Model.Symptom;
import com.witnip.diagnosis.R;

import java.util.ArrayList;

public class SelectedSymptomAdapter extends RecyclerView.Adapter<SelectedSymptomAdapter.SelectedSymptomViewHolder> {

    Context context;
    ArrayList<Symptom> selectedSymptoms;

    public SelectedSymptomAdapter(Context context, ArrayList<Symptom> selectedSymptoms) {
        this.context = context;
        this.selectedSymptoms = selectedSymptoms;
    }

    public class SelectedSymptomViewHolder extends RecyclerView.ViewHolder {

        TextView txtSelectedSymptom;
        public SelectedSymptomViewHolder(@NonNull View itemView) {
            super(itemView);
            txtSelectedSymptom = itemView.findViewById(R.id.txtSelectedSymptom);
        }
    }

    @NonNull
    @Override
    public SelectedSymptomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.selected_symptom,parent,false);
        SelectedSymptomViewHolder holder = new SelectedSymptomViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull SelectedSymptomViewHolder holder, int position) {
        Symptom symptom = selectedSymptoms.get(position);
        holder.txtSelectedSymptom.setText(symptom.getName());
    }

    @Override
    public int getItemCount() {
        return selectedSymptoms.size();
    }
}
